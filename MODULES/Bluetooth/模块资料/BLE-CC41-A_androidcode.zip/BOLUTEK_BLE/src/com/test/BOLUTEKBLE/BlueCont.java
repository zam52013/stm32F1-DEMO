package com.test.BOLUTEKBLE;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;






import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.SimpleExpandableListAdapter;
import android.widget.TextView;

@SuppressLint("NewApi")
public class BlueCont extends Activity {

	private String mDeviceName;
	private String mDeviceAddress;
	private TextView tvaddress;
	private TextView tvstate;
	private EditText tvdata;
	private ExpandableListView elist;
	private boolean result;
	private BluetoothLeService mBluetoothLeService;
	
    private BluetoothGattCharacteristic mNotifyCharacteristic;
	
    private ArrayList<ArrayList<BluetoothGattCharacteristic>> mGattCharacteristics =
            new ArrayList<ArrayList<BluetoothGattCharacteristic>>();
	// ������������������ڡ�
	private final ServiceConnection mServiceConnection = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName componentName,
				IBinder service) {
			mBluetoothLeService = ((BluetoothLeService.LocalBinder) service)
					.getService();
			Log.e("a", "��ʼ����������");
			if (!mBluetoothLeService.initialize()) {
				Log.e("a", "�޷���ʼ������");
				finish();
			}
			// �Զ����ӵ�װ���ϳɹ�������ʼ����
			result = mBluetoothLeService.connect(mDeviceAddress);
			
			
		}

		@Override
		public void onServiceDisconnected(ComponentName componentName) {
			mBluetoothLeService.disconnect();
			mBluetoothLeService = null;
		}
	};

	// ���������¼��ķ����ˡ�
	// action_gatt_connected���ӵ�����������ó��Э����
	// action_gatt_disconnected���ӹ�ó��Э���ķ������Ͽ���
	// action_gatt_services_discovered����ó��Э���ķ����֡�
	// action_data_available�����豸�������ݡ�������������Ķ�
	// ��֪ͨ������
	private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			final String action = intent.getAction();
			if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
				result = true;
				Log.e("a", "���˹㲥1");
				tvstate.setText("����");

			} else if (BluetoothLeService.ACTION_GATT_DISCONNECTED
					.equals(action)) {
				result = false;
				Log.e("a", "���˹㲥2");
				mBluetoothLeService.close();
				tvstate.setText("δ����");
				// clearUI();

			} else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED
					.equals(action)) {
				// ��ʾ���е�֧�ַ�����ص���û����档
				Log.e("a", "���˹㲥3");
				List<BluetoothGattService> supportedGattServices = mBluetoothLeService
						.getSupportedGattServices();
				 displayGattServices(mBluetoothLeService.getSupportedGattServices());
				for(int i=0;i<supportedGattServices.size();i++){
					Log.e("a","1:BluetoothGattService UUID=:"+supportedGattServices.get(i).getUuid());
					List<BluetoothGattCharacteristic> cs = supportedGattServices.get(i).getCharacteristics();
					for(int j=0;j<cs.size();j++){
						Log.e("a","2:   BluetoothGattCharacteristic UUID=:"+cs.get(j).getUuid());
						
					
							List<BluetoothGattDescriptor> ds = cs.get(j).getDescriptors();
							for(int f=0;f<ds.size();f++){
								Log.e("a","3:      BluetoothGattDescriptor UUID=:"+ds.get(f).getUuid());
								
								 byte[] value = ds.get(f).getValue();
								
								 Log.e("a","4:     			value=:"+Arrays.toString(value));
								 Log.e("a","5:     			value=:"+Arrays.toString( ds.get(f).getCharacteristic().getValue()));
							}
					}
				}
				
			} else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
				Log.e("a", "���˹㲥4--->data:"+intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
//				displayData(intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
				i++;
				DATA = ""+DATA+"\n��"+i+"����"+intent.getStringExtra(BluetoothLeService.EXTRA_DATA);
				Log.e("a4", ""+DATA);
				tvdata.setText(""+DATA);
				tvdata.setSelection(DATA.length());
			}else if(BluetoothLeService.ACTION_RSSI.equals(action)){
				Log.e("a", "���˹㲥5");
				tvrssi.setText("RSSI:"+intent
						.getStringExtra(BluetoothLeService.ACTION_DATA_RSSI));
			}
		}
	};
    private ExpandableListView mGattServicesList;
	private EditText et_send;
	private String DATA;
	private int i;
	private ArrayList<BluetoothGattCharacteristic> charas;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gatt_services_characteristics2);

		Intent intent = getIntent();
		mDeviceName = intent.getStringExtra("name");
		mDeviceAddress = intent.getStringExtra("andrass");

		Log.e("a", "����"+mDeviceName+"��ַ"+mDeviceAddress);
		getActionBar().setTitle(mDeviceName);
		getActionBar().setDisplayHomeAsUpEnabled(true);

		DATA = "";
		i = 0;
		
		tvaddress = (TextView) findViewById(R.id.device_address);
		tvaddress.setText(mDeviceAddress);

		tvstate = (TextView) findViewById(R.id.connection_state);
		tvdata = (EditText) findViewById(R.id.data_value);
		tvdata.setMovementMethod(ScrollingMovementMethod.getInstance()); 
		//tvdata.setSelected(true);
		tvdata.requestFocus();//get the focus
		tvrssi = (TextView) findViewById(R.id.data_rssi);

		
		mGattServicesList = (ExpandableListView) findViewById(R.id.gatt_services_list);
        mGattServicesList.setOnChildClickListener(servicesListClickListner);
		
        et_send = (EditText) findViewById(R.id.et_send);
		Button btsend = (Button) findViewById(R.id.btsend);
		
		btsend.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				byte[]bb= new byte[]{(byte)1,2,3};
				String sendstr = et_send.getText().toString();
				Boolean boolean1 = mBluetoothLeService.write(mNotifyCharacteristic,sendstr);
				Log.e("a", "����UUID"+mNotifyCharacteristic.getUuid().toString()+"�Ƿ��ͳɹ�::"+boolean1);
			}
		});
		
		 flg = true;
		Button btrssi=(Button) findViewById(R.id.btrssi);
		btrssi.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						while (flg) {
						// TODO Auto-generated method stub
							try {
								Thread.sleep(1000);	
								flg=mBluetoothLeService.readrssi();	
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								Log.e("a","������");
							}
						}
					
					}
				}).start();
			}
		});
		registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
		Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
		bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
		
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		/**
		 * ע��㲥
		 */
		registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
		if (mBluetoothLeService != null) {
			Log.e("a", "����");
			result = mBluetoothLeService.connect(mDeviceAddress);
			Log.e("a", "��������Ľ��=" + result);

		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.action_settings:

			if (result) {
				result = false;
				mBluetoothLeService.disconnect();
			}
			onBackPressed();
			break;
		case R.id.action_cont:
			result = mBluetoothLeService.connect(mDeviceAddress);

			break;

		case R.id.action_close:
			if (result) {
				result = false;
			//	mBluetoothLeService.disconnect();
				Log.e("a", "�Ͽ���");
				mBluetoothLeService.close();
				tvstate.setText("���ӶϿ�");
			}

			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * ���ٹ㲥������
	 */
	@Override
	protected void onPause() {
		super.onPause();
		flg=false;
		unregisterReceiver(mGattUpdateReceiver);
	
	}
	/**
	 * ��������
	 */
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

		unbindService(mServiceConnection);

	}
	
    // ������ע����expandablelistview���ݽṹ
	//  ��UI��
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null)
        	return;
        String uuid = null;
        String unknownServiceString = "service_UUID";
        String unknownCharaString = "characteristic_UUID";
        ArrayList<HashMap<String, String>> gattServiceData = new ArrayList<HashMap<String, String>>();
        ArrayList<ArrayList<HashMap<String, String>>> gattCharacteristicData
                = new ArrayList<ArrayList<HashMap<String, String>>>();
        mGattCharacteristics = new ArrayList<ArrayList<BluetoothGattCharacteristic>>();

        // ѭ����������
        for (BluetoothGattService gattService : gattServices) {
            HashMap<String, String> currentServiceData = new HashMap<String, String>();
            uuid = gattService.getUuid().toString();
            currentServiceData.put(
                    "NAME", SampleGattAttributes.lookup(uuid, unknownServiceString));
            currentServiceData.put("UUID", uuid);
            gattServiceData.add(currentServiceData);

            ArrayList<HashMap<String, String>> gattCharacteristicGroupData =
                    new ArrayList<HashMap<String, String>>();
            List<BluetoothGattCharacteristic> gattCharacteristics =
                    gattService.getCharacteristics();
            charas =
                    new ArrayList<BluetoothGattCharacteristic>();

            // ѭ����������
            for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
                charas.add(gattCharacteristic);
                HashMap<String, String> currentCharaData = new HashMap<String, String>();
                uuid = gattCharacteristic.getUuid().toString();
                currentCharaData.put(
                        "NAME", SampleGattAttributes.lookup(uuid, unknownCharaString));
                currentCharaData.put("UUID", uuid);
                gattCharacteristicGroupData.add(currentCharaData);
            }
            mGattCharacteristics.add(charas);
            gattCharacteristicData.add(gattCharacteristicGroupData);
        }
        
        final BluetoothGattCharacteristic characteristic = charas.get(charas.size()-1);
        final int charaProp = characteristic.getProperties();
        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
            if (mNotifyCharacteristic != null) {
                mBluetoothLeService.setCharacteristicNotification(
                        mNotifyCharacteristic, false);
                mNotifyCharacteristic = null;
            }
            mBluetoothLeService.readCharacteristic(characteristic);

        }
        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
            mNotifyCharacteristic = characteristic;
            mBluetoothLeService.setCharacteristicNotification(
                    characteristic, true);
        }

       /* SimpleExpandableListAdapter gattServiceAdapter = new SimpleExpandableListAdapter(
                this,
                gattServiceData,
                android.R.layout.simple_expandable_list_item_2,
                new String[] {"NAME", "UUID"},
                new int[] { android.R.id.text1, android.R.id.text2 },
                gattCharacteristicData,
                android.R.layout.simple_expandable_list_item_2,
                new String[] {"NAME", "UUID"},
                new int[] { android.R.id.text1, android.R.id.text2 }
        );
        mGattServicesList.setAdapter(gattServiceAdapter);*/
    }
    
    
    private final ExpandableListView.OnChildClickListener servicesListClickListner =
            new ExpandableListView.OnChildClickListener() {
                @Override
                public boolean onChildClick(ExpandableListView parent, View v, int groupPosition,
                                            int childPosition, long id) {
                	Log.e("a","�����");
                    if (mGattCharacteristics != null) {
                        final BluetoothGattCharacteristic characteristic = mGattCharacteristics.get(groupPosition).get(childPosition);
                        final int charaProp = characteristic.getProperties();
                        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
                            if (mNotifyCharacteristic != null) {
                                mBluetoothLeService.setCharacteristicNotification(
                                        mNotifyCharacteristic, false);
                                mNotifyCharacteristic = null;
                            }
                            mBluetoothLeService.readCharacteristic(characteristic);

                        }
                        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                            mNotifyCharacteristic = characteristic;
                            mBluetoothLeService.setCharacteristicNotification(
                                    characteristic, true);
                        }
                        return true;
                    }
                    return false;
                }
                
    };
	private boolean flg;
	private TextView tvrssi;

    private void clearUI() {
        mGattServicesList.setAdapter((SimpleExpandableListAdapter) null);
        tvdata.setText("ľ������");
    }

	/**
	 * ע��㲥
	 * @return
	 */
    
    
	private static IntentFilter makeGattUpdateIntentFilter() {
		final IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
		intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
		intentFilter
				.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
		intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
		intentFilter.addAction(BluetoothLeService.ACTION_RSSI);
		intentFilter.addAction(BluetoothLeService.ACTION_DATA_RSSI);
		return intentFilter;
	}
	
}
